package com.example.aiworkertycoon

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private var cash = 100
    private var workers = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(Color.rgb(245, 247, 250))
        }

        val title = TextView(this).apply {
            text = "AI Worker Tycoon"
            textSize = 30f
            setTextColor(Color.rgb(25, 35, 55))
            gravity = Gravity.CENTER
        }

        val stats = TextView(this).apply {
            textSize = 20f
            gravity = Gravity.CENTER
        }

        val hire = Button(this).apply {
            text = "Hire AI Worker — $50"
            textSize = 18f
        }

        val work = Button(this).apply {
            text = "Run Workday +$25"
            textSize = 18f
            isEnabled = false
        }

        fun update() {
            stats.text = "Cash: $$cash\nAI Workers: $workers"
            work.isEnabled = workers > 0
            hire.isEnabled = cash >= 50
        }

        hire.setOnClickListener {
            cash -= 50
            workers++
            update()
        }

        work.setOnClickListener {
            cash += workers * 25
            update()
        }

        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(stats, LinearLayout.LayoutParams(-1, -2).apply {
            setMargins(0, 32, 0, 24)
        })
        root.addView(hire, LinearLayout.LayoutParams(-1, -2).apply {
            setMargins(0, 8, 0, 8)
        })
        root.addView(work, LinearLayout.LayoutParams(-1, -2))

        update()
        setContentView(root)
    }
}
